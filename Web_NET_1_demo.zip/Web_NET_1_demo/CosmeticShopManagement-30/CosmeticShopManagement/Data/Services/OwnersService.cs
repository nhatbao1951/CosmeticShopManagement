﻿using CosmeticShopManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CosmeticShopManagement.Data.Services
{
    public class OwnersService : IOwnersService
    {
        private readonly AppDbContext _context;
        public OwnersService(AppDbContext context)
        {
            _context = context;
        }
        public async Task AddAsync(Owner owner)
        {
            await _context.Owners.AddAsync(owner);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var result = await _context.Owners.FirstOrDefaultAsync(n => n.OwnerId == id);
            _context.Owners.Remove(result);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Owner>> GetAllAsync()
        {
            var result = await _context.Owners.ToListAsync();
            return result;
        }

        public async Task<Owner> GetByIdAsync(int id)
        {
            var result = await _context.Owners.FirstOrDefaultAsync(n => n.OwnerId == id);
            return result;
        }

        public async Task<Owner> UpdateAsync(int id, Owner newOwner)
        {
            _context.Update(newOwner);
            await _context.SaveChangesAsync();
            return newOwner;
        }


    }
}
