﻿using CosmeticShopManagement.Models;

namespace CosmeticShopManagement.Data.Services
{
    public interface IOwnersService
    {
        Task<IEnumerable<Owner>> GetAllAsync();

        Task<Owner> GetByIdAsync(int id);

        Task AddAsync(Owner owner);

        Task<Owner> UpdateAsync(int id, Owner newOwner);

        Task DeleteAsync(int id);
    }
}
