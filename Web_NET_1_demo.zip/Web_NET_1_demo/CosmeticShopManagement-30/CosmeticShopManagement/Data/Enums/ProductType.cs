﻿namespace CosmeticShopManagement.Data
{
    public enum ProductType
    {
        Hair = 1,
        Perfume,
        Skincare,
        Body,
        Dental,
        Beard,
        Functionalfoods
    }
}
