﻿using System.ComponentModel.DataAnnotations;

namespace CosmeticShopManagement.Models
{
    public class Owner
    {
        [Key]
        public int OwnerId { get; set; }


        [Display(Name = "OwnerName")]
        public string? OwnerName { get; set; }
        [Required(ErrorMessage = "Profile Name is required")]
        [Display(Name = "OwnerPicture")]
        public string? OwnerPicture { get; set; }
        [Required(ErrorMessage = "Profile Picture is required")]
        [Display(Name ="Biography")]
        public string? Bio { get; set; }
        [Required(ErrorMessage = "Profile Bio is required")]
        // Relashionship
        public List<Owner_Product>? Owner_Products { get; set; }
    }
}
