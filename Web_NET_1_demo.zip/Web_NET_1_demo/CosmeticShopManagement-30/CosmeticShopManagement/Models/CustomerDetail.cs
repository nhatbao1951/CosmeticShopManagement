﻿using System.ComponentModel.DataAnnotations;

namespace CosmeticShopManagement.Models
{
    public partial class CustomerDetail
    {

        public int Id { get; set; }
        [Display(Name = "CustomerName")]
        public string? Name { get; set; }
        [Display(Name = "CustomerEmail")]
        public string? Email { get; set; }
        [Display(Name = "CustomerPassword")]
        public string? Password { get; set; }
        [Display(Name = "CustomerMobile")]
        public string? Mobile { get; set; }

        public List<CustomerDetail>? customerDetails { get; set; }
    }
}