﻿using System;
namespace CosmeticShopManagement.Views.Products
{
	public class AddProduct
	{
		public AddProduct()
		{
		}
	}
}

