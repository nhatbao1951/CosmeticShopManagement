﻿using CosmeticShopManagement.Data;
using CosmeticShopManagement.Data.Services;
using CosmeticShopManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace CosmeticShopManagement.Controllers
{
    public class OwnerController : Controller
    {
        private readonly IOwnersService _service;

        public OwnerController(IOwnersService service)
        {
            _service = service;
        }


        public async Task<IActionResult> Index()
        {
            var data = await _service.GetAllAsync();
            return View(data);
        }
        //Get and Create Owner
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create([Bind("OwnerName,OwnerPicture,Bio")] Owner owner)
        {
            if (ModelState.IsValid)
            {
                return View(owner);
            }
            await _service.AddAsync(owner);

            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Details(int id)
        {
            var ownerDetails = await _service.GetByIdAsync(id);
            if(ownerDetails == null)
            {
                return RedirectToAction(nameof(NotFound));
            }
            return View(ownerDetails);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var ownerDetails = await _service.GetByIdAsync(id);

            if(ownerDetails == null)
            {
                return RedirectToAction(nameof(NotFound));
            }
            return View(ownerDetails);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("OwnerName,OwnerPicture,Bio")] Owner owner)
        {
            if (ModelState.IsValid)
            {
                return View(owner);
            }
            await _service.UpdateAsync(id,owner);

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var ownerDetails = await _service.GetByIdAsync(id);

            if (ownerDetails == null)
            {
                return RedirectToAction(nameof(NotFound));
            }
            return View(ownerDetails);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ownerDetails = await _service.GetByIdAsync(id);
            if (ownerDetails == null)
            {

                return RedirectToAction(nameof(NotFound));

            }
            await _service.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
